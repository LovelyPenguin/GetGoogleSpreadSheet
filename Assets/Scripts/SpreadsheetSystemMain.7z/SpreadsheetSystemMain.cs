﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Linq;
using LitJson;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Sheets.v4;
using Google.Apis.Sheets.v4.Data;
using Google.Apis.Services;
using Google.Apis.Util.Store;
using Newtonsoft.Json;
using UnityEditor;
using UnityEngine;

public class SpreadsheetSystem
{

    //private SpreadsheetSystem() {/* 파라미터 없는 생성자는 사용 불가 */ }

    // 해당 주석 지우고, 해당 생성자를 이용해 초기화하세요.
    //public SpreadsheetSystem(/* 파라미터 전달할 것 작성하세요.*/)
    //{
    //    ConnectToGoogle(/* Argument 전달할 것 작성하세요.*/);
    //}
    //public virtual JsonData ReadFile(/* 파라미터 전달할 것 작성하세요.*/)
    //{

    //}

    static string[] scope = { SheetsService.Scope.Spreadsheets };

    public static string sheetID
    {
        get
        {
            return "NULL";
        }
    }
    public static string sheetRange
    {
        get
        {
            return "A2:C";
        }
    }                                           // 스프레드시트 범위 (A2열부터 C열까지)
    static IList<IList<System.Object>> objNeRecords;

    public static string debugVersion;     // 디버그 버전
    public static string releseVersion;    // 릴리즈 버전

    //private void ConnectToGoogle(/* 파라미터 전달할 것 작성하세요.*/)
    //{

    //}

    /// <summary>
    /// 디버그 버전을 추가함
    /// </summary>
    //[MenuItem("Builder/Debug/Write Debug version")]
    public virtual void WriteFile()
    {
        Debug.Log("Write Debug Log");

        AutoAddCellsSeting(false);
        MakeJSON();
    }

    /// <summary>
    /// 버전을 가져옴
    /// </summary>
    /// <returns></returns>
    [MenuItem("Builder/Debug/Read Debug version")]
    public static string ReadFile()
    {
        Debug.Log("Read Debug Log");
        List<VersionInfo> infoJson = new List<VersionInfo>();

        if (File.Exists(Application.dataPath + "testInfo.json"))
        {
            Debug.Log("파일을 불러왔습니다.");
            string jsonStr = File.ReadAllText(Application.dataPath + "testInfo.json");

            JsonData playData = JsonMapper.ToObject(jsonStr);
            if (playData.Count - 1 > 0)
            {
                MakeJSON();
                AutoAddCellsSeting(false);
                Debug.Log("Last Relese Version : " + playData[playData.Count - 1]["Relese"].ToString());
                return playData[playData.Count - 1]["Relese"].ToString();
            }
            else
            {
                Debug.LogError("Debug 버전을 불러오는데 실패했습니다. 배열 인덱스 값이 0보다 작습니다.");
                return null;
            }
        }
        else
        {
            Debug.Log("파일을 불러올 수 없습니다.");
            return null;
        }
    }

    /// <summary>
    /// JSON만드는 함수
    /// </summary>
    //[MenuItem("Builder/Save JSON")]
    public static void MakeJSON()
    {
        JsonData infoJson = new JsonData();
        infoJson = new JsonData();

        var service = AuthorizeGoogleApp();
        List<VersionInfo> testNumber = new List<VersionInfo>();

        String spreadsheetId = sheetID;
        String range = sheetRange;

        SpreadsheetsResource.ValuesResource.GetRequest getRequest =
                   service.Spreadsheets.Values.Get(spreadsheetId, range);

        ValueRange response = getRequest.Execute();
        IList<IList<System.Object>> values = response.Values;
        if (values != null && values.Count > 0)
        {
            //Console.WriteLine("Data, Debug, Relese");
            foreach (var row in values)
            {
                row[0] = row[0].ToString().Remove(row[0].ToString().Length - 1);
                testNumber.Add(new VersionInfo(row[0].ToString(), row[1].ToString(), row[2].ToString()));
            }
            Debug.Log("JSON export complete");
        }
        else
        {
            //Console.WriteLine("No data found.");
        }

        infoJson = JsonMapper.ToJson(testNumber);
        File.WriteAllText(Application.dataPath + "testInfo.json", infoJson.ToString());

        //return infoJson;
    }

    /// <summary>
    /// 스프레드시트를 사용하기 위한 사용자 인증
    /// </summary>
    /// <returns></returns>
    private static SheetsService AuthorizeGoogleApp()
    {
        Debug.Log("Autorized Google Spreadsheet");
        UserCredential credential;

        using (var stream =
            new FileStream("C:/credentials.json", FileMode.Open, FileAccess.Read))         // 내 인증키 위치. 초기 셋팅은 C드라이브에 있음
        {
            string credPath = System.Environment.GetFolderPath(
                System.Environment.SpecialFolder.Personal);
            credPath = Path.Combine(credPath, ".credentials/Sheet_Server_Token.json");

            //string credPath = "Sheet_Server_Token.json";

            credential = GoogleWebAuthorizationBroker.AuthorizeAsync(
                GoogleClientSecrets.Load(stream).Secrets,
                scope,
                "user",
                CancellationToken.None,
                new FileDataStore(credPath, true)).Result;
            Console.WriteLine("Credential file saved to: " + credPath);
        }

        // Create Google Sheets API service.
        var service = new SheetsService(new BaseClientService.Initializer()
        {
            HttpClientInitializer = credential,
            //ApplicationName = ApplicationName,
        });

        return service;
    }

    /// <summary>
    /// 셀의 범위를 가져오는 모양
    /// </summary>
    /// <param name="service"></param>
    /// <returns></returns>
    protected static string GetRange(SheetsService service)
    {
        // Define request parameters.
        String spreadsheetId = sheetID;
        String range = sheetRange;

        SpreadsheetsResource.ValuesResource.GetRequest getRequest =
                   service.Spreadsheets.Values.Get(spreadsheetId, range);

        ValueRange getResponse = getRequest.Execute();
        IList<IList<System.Object>> getValues = getResponse.Values;

        int currentCount = getValues.Count() + 1;

        String newRange = "A" + currentCount + ":A";

        return newRange;
    }

    /// <summary>
    /// 셀의 값들을 가져옴
    /// </summary>
    /// <param name="service"></param>
    static void GetCells(SheetsService service)
    {
        String spreadsheetId = sheetID;
        String range = sheetRange;

        SpreadsheetsResource.ValuesResource.GetRequest getRequest =
                   service.Spreadsheets.Values.Get(spreadsheetId, range);

        ValueRange response = getRequest.Execute();
        IList<IList<System.Object>> values = response.Values;
        if (values != null && values.Count > 0)
        {
            //Console.WriteLine("Data, Debug, Relese");
            foreach (var row in values)
            {
                debugVersion = row[1].ToString();
                releseVersion = row[2].ToString();
            }
        }
        else
        {
            //Console.WriteLine("No data found.");
        }
    }

    /// <summary>
    /// 셀 입력 담당
    /// </summary>
    /// <returns></returns>
    private static IList<IList<System.Object>> GenerateData(bool isDebug)
    {
        List<IList<System.Object>> objNewRecords = new List<IList<System.Object>>();

        IList<System.Object> obj = new List<System.Object>();

        float debugNumber;      // 일단 디버그 버전을 +1씩 해야해서 만든 변수 (string -> float -> string)
        double releseNumber = double.Parse(releseVersion);      // 위에 DebugNumber랑 똑같은 이유로 만든 변수
        string buildTime = DateTime.Now.ToString("yyyy.MM.dd-HH.mm-");      // 실행된 시간을 기록함
        string dateDebugVersion;        // 날짜 + 디버그 버전을 합치기 위해 있는 string변수

        debugVersion = debugVersion.Remove(0, buildTime.Length);
        debugNumber = float.Parse(debugVersion);

        // 만약 디버그 버전이면
        if (isDebug)
        {
            debugNumber += 1f;
        }
        // 만약 릴리즈 버전이면
        else if (!isDebug)
        {
            //debugNumber += 1f;
            releseNumber += 0.1f;
        }
        releseNumber = Math.Truncate(releseNumber * 100) / 100;     // 소숫점 한자리 빼고 전부 지워버림

        dateDebugVersion = buildTime + debugNumber.ToString();

        obj.Add(buildTime);
        obj.Add(dateDebugVersion);
        obj.Add(releseNumber.ToString());

        objNewRecords.Add(obj);

        return objNewRecords;
    }

    /// <summary>
    /// 적용된 셀 정보를 업데이트 하는 함수
    /// </summary>
    /// <param name="values"></param>
    /// <param name="spreadsheetId"></param>
    /// <param name="newRange"></param>
    /// <param name="service"></param>
    private static void UpdatGoogleSheetinBatch(IList<IList<System.Object>> values, string spreadsheetId, string newRange, SheetsService service)
    {
        SpreadsheetsResource.ValuesResource.AppendRequest request =
           service.Spreadsheets.Values.Append(new ValueRange() { Values = values }, spreadsheetId, newRange);
        request.InsertDataOption = SpreadsheetsResource.ValuesResource.AppendRequest.InsertDataOptionEnum.INSERTROWS;
        request.ValueInputOption = SpreadsheetsResource.ValuesResource.AppendRequest.ValueInputOptionEnum.USERENTERED;
        var response = request.Execute();
    }

    /// <summary>
    /// 셀을 추가하는데 필수 적인 함수들 모음
    /// 이 함수만 호출하면 편함
    /// </summary>
    /// <param name="values"></param>
    /// <param name="spreadsheetId"></param>
    /// <param name="newRange"></param>
    /// <param name="service"></param>
    /// <param name="isDebug"></param>
    public static void AutoAddCellsSeting(bool isDebug)
    {
        GetCells(AuthorizeGoogleApp());
        objNeRecords = GenerateData(isDebug);
        UpdatGoogleSheetinBatch(objNeRecords, sheetID, GetRange(AuthorizeGoogleApp()), AuthorizeGoogleApp());
    }
}

public class VersionInfo
{
    public string Date;
    public string Debug;
    public string Relese;

    /// <summary>
    /// 생성자
    /// </summary>
    /// <param name="date"></param>
    /// <param name="debug"></param>
    /// <param name="relese"></param>
    public VersionInfo(string date, string debug, string relese)
    {
        Date = date;
        Debug = debug;
        Relese = relese;
    }
}